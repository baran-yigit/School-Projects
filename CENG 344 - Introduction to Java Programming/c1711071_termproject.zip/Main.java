
import javax.swing.*;
import javax.swing.plaf.nimbus.NimbusLookAndFeel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final int WIDTH = 500;
    private static final int HEIGHT = 500;

    private WhiteBlack turn;
    private GameBoard board = new GameBoard();

    private JButton[][] buttons = new JButton[8][8];
    private BoardTile lastTile;

    private ChessTimer whiteTimer;
    private ChessTimer blackTimer;

    private JLabel turnLabel;
    private JLabel whiteTimeLabel;
    private JLabel blackTimeLabel;

    public Main() {
        setTitle("Simple 1v1 Chess");
        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        createContent();
        newGame();
        startTimer();

        setResizable(false);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    // ------------------------------------------------------------------------
    // Game Initialization
    // ------------------------------------------------------------------------

    private void newGame() {
        turn = WhiteBlack.WHITE;
        board.initialize();
        refresh();

        whiteTimer = new ChessTimer();
        blackTimer = new ChessTimer();
        resumeTimer();
        updateLabels();
    }

    // ------------------------------------------------------------------------
    // GUI Setup
    // ------------------------------------------------------------------------

    private void createContent() {
        createMenu();

        // --------------------------------------------------------------------
        // Main Grid (Board Buttons)
        // --------------------------------------------------------------------

        JPanel panel1 = new JPanel();
        panel1.setLayout(new GridLayout(8, 8));
        add(panel1);

        for (int rank = 0; rank < 8; rank++) {
            for (int file = 0; file < 8; file++) {
                JButton button = new JButton();
                button.setFont(new Font("Arial Unicode MS", Font.BOLD, 24));
                button.addActionListener(new ButtonListener(rank, file));

                panel1.add(button);
                buttons[rank][file] = button;
            }
        }

        // --------------------------------------------------------------------
        // Status Bar (Timers, Current Turn Label)
        // --------------------------------------------------------------------

        JPanel panel2 = new JPanel();
        panel2.setLayout(new GridLayout(1, 3));
        add(panel2, BorderLayout.SOUTH);

        JPanel panel3 = new JPanel();
        JPanel panel4 = new JPanel();
        JPanel panel5 = new JPanel();

        panel2.add(panel3);
        panel2.add(panel4);
        panel2.add(panel5);

        whiteTimeLabel = new JLabel();
        panel3.add(new JLabel("White time:"));
        panel3.add(whiteTimeLabel);

        turnLabel = new JLabel();
        panel4.add(turnLabel);

        blackTimeLabel = new JLabel();
        panel5.add(new JLabel("Black time:"));
        panel5.add(blackTimeLabel);
    }

    private void createMenu() {
        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        JMenu menu = new JMenu("Game");
        menuBar.add(menu);

        // --------------------------------------------------------------------
        // New Game
        // --------------------------------------------------------------------

        JMenuItem newGame = new JMenuItem("New Game");
        menu.add(newGame);
        newGame.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                newGame();
            }
        });

        menu.addSeparator();

        // --------------------------------------------------------------------
        // Saving and Loading
        // --------------------------------------------------------------------

        final SavedGame serializer = new SavedGame();

        JMenuItem loadGame = new JMenuItem("Load Game");
        menu.add(loadGame);
        loadGame.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser chooser = new JFileChooser();

                pauseTimers();

                if (chooser.showOpenDialog(Main.this) == JFileChooser.APPROVE_OPTION) {
                    try {
                        State state = serializer.load(chooser.getSelectedFile());

                        turn = state.turn;
                        board = state.board;
                        refresh();

                        whiteTimer = new ChessTimer(state.whiteTime);
                        blackTimer = new ChessTimer(state.blackTime);
                        updateLabels();
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(Main.this, ex.getMessage());
                    }
                }
                resumeTimer();
            }
        });

        JMenuItem saveGame = new JMenuItem("Save Game");
        menu.add(saveGame);
        saveGame.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser chooser = new JFileChooser();

                pauseTimers();

                if (chooser.showSaveDialog(Main.this) == JFileChooser.APPROVE_OPTION) {
                    try {
                        serializer.save(chooser.getSelectedFile(), new State(board, turn, whiteTimer.getElapsed(), blackTimer.getElapsed()));
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(Main.this, ex.getMessage());
                    }
                }
                resumeTimer();
            }
        });
    }

    private JButton getButtonAt(BoardTile t) {
        return buttons[t.getRank()][t.getFile()];
    }

    // ------------------------------------------------------------------------
    // Timers
    // ------------------------------------------------------------------------

    private void startTimer() {
        new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                whiteTimer.update();
                blackTimer.update();
                updateLabels();
            }
        }).start();
    }

    private void pauseTimers() {
        whiteTimer.pause();
        blackTimer.pause();
    }

    private void resumeTimer() {
        if (turn == WhiteBlack.WHITE) {
            whiteTimer.resume();
        } else {
            blackTimer.resume();
        }
    }

    // ------------------------------------------------------------------------
    // Refresh Tile, Clear Selection
    // ------------------------------------------------------------------------

    private void refresh() {
        for (int rank = 0; rank < 8; rank++) {
            for (int file = 0; file < 8; file++) {
            	BoardTile t = new BoardTile(rank, file);
                Piece moment = board.getPieceAt(t);

                if ((rank + file) % 2 == 0) {
                    getButtonAt(t).setBackground(new Color(255, 85, 87));
                } else {
                    getButtonAt(t).setBackground(new Color(200, 51, 25));
                }
                getButtonAt(t).setText(moment == null ? null : moment.toString());
            }
        }
        turnLabel.setText("(" + turn.toString() + " to move)");
    }

    private void updateLabels() {
        int w = (int) (whiteTimer.getElapsed() / 1e3);
        int b = (int) (blackTimer.getElapsed() / 1e3);
        whiteTimeLabel.setText(String.format("%d:%02d", w / 60, w % 60));
        blackTimeLabel.setText(String.format("%d:%02d", b / 60, b % 60));
    }

    // ------------------------------------------------------------------------
    // Selection and Movement
    // ------------------------------------------------------------------------

    private class ButtonListener implements ActionListener {
        private BoardTile thisTile;

        public ButtonListener(int rank, int file) {
            thisTile = new BoardTile(rank, file);
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            if (lastTile == null) {
                if (board.isOccupiedByPlayer(thisTile, turn)) {
                    lastTile = thisTile;
                    for (BoardTile tile : board.getPieceAt(thisTile).getAllSafeMoves(thisTile)) {
                        if (board.isOccupied(tile)) {
                            getButtonAt(tile).setBackground(new Color(150, 100, 100));
                        } else {
                            getButtonAt(tile).setBackground(new Color(100, 150, 100));
                        }
                    }

                    getButtonAt(thisTile).setBackground(Color.green);
                }
            } else {
                if (board.move(lastTile, thisTile)) {
                    pauseTimers();
                    turn = turn.opposite();

                    if (board.isPlayerInCheckMate(turn)) {
                        JOptionPane.showMessageDialog(Main.this, "Checkmate!");
                        newGame();
                    } else if (board.isPlayerInCheck(turn)) {
                        JOptionPane.showMessageDialog(Main.this, "Check.");
                    }
                    resumeTimer();
                }
                refresh();
                lastTile = null;
            }
        }
    }

    public static void main(String[] args) {
        /**
         * Nimbus is a polished cross-platform look and feel introduced in the Java SE 6 Update 10 (6u10) release.
         * Nimbus uses Java 2D vector graphics to draw the user interface (UI), 
         * rather than static bitmaps, so the UI can be crisply rendered at any resolution.
         * Nimbus is highly customizable. You can use the Nimbus look and feel as is,
         * or you can skin (customize) the look with your own brand.
         */
    	try {
            UIManager.setLookAndFeel(new NimbusLookAndFeel());
        } catch (Exception e) {
            e.printStackTrace();
        }
        new Main();
    }
}

