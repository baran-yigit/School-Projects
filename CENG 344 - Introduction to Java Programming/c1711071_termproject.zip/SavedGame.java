
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class SavedGame {
    /**
     * Reads a game state from the given file.
     * loadFile The input file.
     * return A game state.
     * throws RuntimeException If the file cannot be read.
     * throws RuntimeException If a game state cannot be parsed from the file contents.
     */
    public State load(File loadFile) {
        try (Scanner scanner = new Scanner(loadFile)) {
            try {
            	GameBoard board = new GameBoard();

                WhiteBlack turn = WhiteBlack.valueOf(scanner.next());
                long whiteTime = scanner.nextLong();
                long blackTime = scanner.nextLong();
                scanner.nextLine();

                while (scanner.hasNextLine()) {
                    int rank = scanner.nextInt();
                    int file = scanner.nextInt();
                    String p = scanner.next();
                    String n = scanner.next();
                    scanner.nextLine();

                    BoardTile tile = new BoardTile(rank, file);
                    WhiteBlack pl = WhiteBlack.valueOf(p);

                    Piece piece = loadPiece(board, pl, n);

                    if (board.isOccupied(tile)) {
                        throw new RuntimeException("Duplicate positions in save file.");
                    }

                    board.setPieceAt(tile, piece);
                }

                return new State(board, turn, whiteTime, blackTime);
            } catch (NoSuchElementException | IllegalArgumentException ex) {
                throw new RuntimeException("Malformed line.");
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException("Problem opening file.");
        }
    }

    /**
     * Saves a game state to the given file.
     * saveFile The output file.
     * state    The game state.
     * throws RuntimeException When the file cannot be written.
     */
    public void save(File saveFile, State state) {
        try (PrintWriter writer = new PrintWriter(saveFile)) {
            writer.print(state.turn);
            writer.print(" ");
            writer.print(state.whiteTime);
            writer.print(" ");
            writer.print(state.blackTime);
            writer.print("\n");

            for (int rank = 0; rank < 8; rank++) {
                for (int file = 0; file < 8; file++) {
                    Piece piece = state.board.getPieceAt(new BoardTile(rank, file));

                    if (piece != null) {
                        writer.println(savePiece(rank, file, piece));
                    }
                }
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException("Problem writing file.");
        }
    }

    /**
     * Creates a piece instance with the given board and player.
     * board  The board.
     * player The player.
     * name   The name (type) of the piece.
     * return A piece instance.
     * throws RuntimeException When the name of the piece is unknown.
     */
    private Piece loadPiece(GameBoard board, WhiteBlack player, String name) {
        switch (name) {
            case "Pawn":
                return new Pawn(board, player);
            case "Rook":
                return new Rook(board, player);
            case "Knight":
                return new Knight(board, player);
            case "Bishop":
                return new Bishop(board, player);
            case "Queen":
                return new Queen(board, player);
            case "King":
                return new King(board, player);
        }

        throw new RuntimeException("Unknown piece.");
    }

    /**
     * Serializes a piece's location, player, and type data.
     * rank  The piece's current rank.
     * file  The piece's current file.
     * piece The piece.
     * return A string representation.
     */
    private String savePiece(int rank, int file, Piece piece) {
        return String.format("%d %d %s %s", rank, file, piece.getPlayer().toString(), piece.getClass().getName());
    }
}
