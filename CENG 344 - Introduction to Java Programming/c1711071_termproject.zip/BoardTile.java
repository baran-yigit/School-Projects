
/**
 * Represents a tile on the board.
 */
public class BoardTile {
    private int rank;
    private int file;

    public BoardTile(int rank, int file) {
        this.rank = rank;
        this.file = file;
    }

    public int getRank() {
        return rank;
    }

    public int getFile() {
        return file;
    }

    public String toString() {
        return "" + (char) (file + 65) + (8 - rank);
    }
    /**
     * Determines if the tile exists on the board.
     * return true if the tile is valid, false otherwise.
     */
    public boolean isValid() {
        return rank >= 0 && rank < 8 && file >= 0 && file < 8;
    }
    /**
     * Determines if this tile is equal to the other object.
     * other Another object.
     * return true if the other object is a tile with the same rank and file, false otherwise.
     */
    public boolean equals(Object other) {
        if (other instanceof BoardTile) {
            return ((BoardTile) other).rank == rank && ((BoardTile) other).file == file;
        }
        return false;
    }
}
