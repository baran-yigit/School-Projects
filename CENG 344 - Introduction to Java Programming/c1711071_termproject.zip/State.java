
/**
 * Represents the state of a game.
 */
public class State {
    public GameBoard board;
    public WhiteBlack turn;
    public long whiteTime;
    public long blackTime;

    public State(GameBoard board, WhiteBlack turn, long whiteTime, long blackTime) {
        this.board = board;
        this.turn = turn;
        this.whiteTime = whiteTime;
        this.blackTime = blackTime;
    }
}
