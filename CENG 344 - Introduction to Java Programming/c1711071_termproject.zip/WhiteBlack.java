
public enum WhiteBlack {
    WHITE,
    BLACK;
    /**
     * Get the opposite player.
     * return the opposite player.
     */
    public WhiteBlack opposite() {
        switch (this) {
            case WHITE: return BLACK;
            case BLACK: return WHITE;
        }
        return null;
    }
}
