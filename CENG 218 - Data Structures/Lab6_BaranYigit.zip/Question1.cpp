#include <iostream>
#include <stdlib.h>
using namespace std;
class polygon {
public:
    polygon() { }

    polygon(int n) {
    number=n;
    edges=(int*)malloc(sizeof(int)*n);
    cout<<"Normal constructor allocating ptr."<<endl; }

    polygon(const polygon &obj) {
    number=obj.number;
    edges=(int*)malloc(sizeof(int)*number);
    cout<<"Copy constructor allocating ptr."<<endl;
        for(int i=0;i<number;++i) {
            edges[i]=obj.edges[i]; } }

    ~polygon(){
    free(edges);
    cout<<"Freeing memory!"<<endl; }

    void getEdges() {
        for(int i=0;i<number;++i) {
            cout<<"Enter the edge "<<i+1<<": ";
            cin>>edges[i]; }}

    void getCircumference() {
    int sum=0;
        for(int i=0;i<number;++i) {
            sum+=edges[i]; }
    cout<<"Sum of edges: "<<sum<<endl; }

private:
    int *edges;
    int number;
};

int main() {
int n;
cout<<"Enter number of edges for polygon: ";
cin>>n;
polygon x=polygon(n);
x.getEdges();
x.getCircumference();
polygon copy=x;
copy.getCircumference();
return 0; }
