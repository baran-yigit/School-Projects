#include <iostream>
using namespace std;
class Room {
public:
    void getRoom() {
        cout<<"----------Room Information----------"<<endl;
        cout<<"Enter m2 of room: ";
        cin>>m2;
        cout<<"Does room has a balcony: ";
        cin>>balcony; }

    void printRoom() {
        cout<<"m2: "<<m2<<", balcony: "<<balcony<<endl; }

    int setM2(int m2) {
        this->m2=m2; }

    string setBalcony(string balcony) {
        this->balcony=balcony; }

    int getM2() {
        return m2; }

    string GetBalcony() {
        return balcony; }
private:
    int m2;
    string balcony;
};

class Resident {
public:
    Resident() {}

    void getResident() {
        cout<<"----------Resident Information----------"<<endl;
        cout<<"Name: ";
        cin>>name;
        cout<<"Last name: ";
        cin>>lastname; }

    void PrintResident() {
        cout<<"Resident name: "<<name<<", Resident last name: "<<lastname<<endl; }
private:
    string name,lastname;
};

class House{
public:
    House() {
        room1.getRoom();
        room2.getRoom();
        totalm2=room1.getM2()+room2.getM2(); }

    House(const House &obj) {
        cout<<"Copy constructor allocating ptr."<<endl;
        this->room1=obj.room1;
        this->room2=obj.room2; }

    ~House() {
        cout<<"Destructor in house class ->deleting rooms"<<endl; }

    void AddResident(Resident &person) {
        this->person=person; }

    int getTotalM2() {
        return totalm2; }

    void calculateTotalm2() {
        room1.printRoom();
        room2.printRoom();
        cout<<"total m2 of the house: "<<totalm2<<endl; }
private:
    Room room1,room2;
    Resident person;
    int totalm2;
};
int main() {
Resident y;
y.getResident();
House house1;
house1.AddResident(y);
house1.calculateTotalm2();
y.PrintResident();
House copy=house1;
y.getResident();
House house2;
house2.AddResident(y);
house2.calculateTotalm2();
y.PrintResident();
return 0; }
