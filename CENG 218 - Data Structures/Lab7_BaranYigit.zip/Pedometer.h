#ifndef PEDOMETER_H_
#define PEDOMETER_H_
class Pedometer{
private:
    int length,total,*steps;
    double calori;
public:
        Pedometer();
        Pedometer(int n);
        Pedometer(const Pedometer &obj);
        int& operator[](const int &num);
        int getLength();
        void setLength(int length);
        double getCalori();
        void setCalori(double calori);
        void display();
        int calculatetotal();
        Pedometer& operator=(const Pedometer &rhs);
        ~Pedometer();
};
#endif // PEDOMETER_H_
