
#include<iostream>
using namespace std;
#include "Car.h"
Car::Car(){
total=0;
fuel=0;
length=1;
distance=new int[length];
}
Car::Car(int num){
total=0;
fuel=0;
length=num;
distance=new int[length]; }
Car::Car(const Car &obj){
length=obj.length;
distance=new int[length];
for(int i=0;i<length;i++) {
distance[i]=obj.distance[i]; } }
void Car::getfuel(){
cout<<"Enter the amount of fuel you want to take: "<<endl;
cin>>fuel; }
void Car::getconsumption(){
int c=0;
for(int i=0;i<length;i++){
    cout<<"Enter fuel consumption: "<<endl;
    cin>>distance[i];
    s+=distance[i];
    if(s<fuel){
        cout<<"not enough to fuel go"<<endl;
        distance[i]=0;
        break; } } }
int Car::calculatetotalconsumption(){
total=0;
for(int i=0;i<length;i++){
    total+=distance[i]; }
return total; }
void Car::display(){
cout<<"----------steps-----------"<<endl;
for(int i=0;i<length;i++){
cout<<"Fuel consumption for time "<<i+1<<" "<<distance[i]<<endl; }
cout<<"Total fuel consumption: "<<calculatetotalconsumption()<<endl; }
void Car::displayfuel(){
cout<<"Current fuel status: "<<(fuel-calculatetotalconsumption())<<endl; }
int& Car::operator[](const int &k){
return distance[k]; }
Car& Car::operator[](const Car &obj){
delete[] distance;
length=obj.length;
distance=new int[length];
for(int i=0;i<length;i++){
    distance[i]=obj.distance[i]; }
return this; }
Car::~Car(){
delete[] distance;
cout<<"Free memory."<<endl; }
