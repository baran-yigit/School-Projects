#include<iostream>
using namespace std;
#include "Pedometer.h"
Pedometer::Pedometer(){
total=0;
length=1;
steps=new int[length]; }
Pedometer::Pedometer(int n){
total=0;
length=n;
steps=new int[length];
for(int i=0;i<length;i++){
    cout<<"Enter steps: "<<endl;
    cin>>steps[i]; } }
Pedometer::Pedometer(const Pedometer &obj){
    length=obj.length;
    steps=new int[length];
for(int i=0;i<length;i++){
steps[i]=obj.steps[i]; } }
Pedometer& Pedometer::operator=(const Pedometer &rhs){
cout<<"Overloaded assignment operator:"<<endl;
delete[] steps;
length=rhs.length;
steps=new int[length];
for(int i=0;i<length;i++){
steps[i]=rhs.steps[i]; }
return *this; }
int& Pedometer::operator[](const int &num){
    return steps[num]; }
int Pedometer::getLength(){
    return length; }
void Pedometer::setLength(int length){
this->length=length; }
double Pedometer::getCalori(){
return calori; }
void Pedometer::setCalori(double calori){
this->calori=calori; }
int Pedometer::calculatetotal(){
for(int i=0;i<length;i++){
total+=steps[i]; }
return total; }
void Pedometer::display(){
cout<<"---steps-----"<<endl;
for(int i=0;i<length;i++){
cout<<"step "<<i<<" :"<<steps[i]<<endl; }
cout<<"Total steps: "<<calculatetotal()<<endl;
cout<<"Total calori: "<<(calculatetotal()/2)*0.05<<endl; }
Pedometer::~Pedometer(){
delete[] steps;
cout<<"Free memory"<<endl; }
