#ifndef BANK_H_
#define BANK_H_
class Bank{
private:
    int account_no,length;
    string account_type,name;
    float balance;
    int *size;
public:
    Bank();
    Bank(int num);
    void deposit(const int &num);
    void withdraw(const int &num);
    void display();
    void setinputs();
    ~Bank();
};
#endif // BANK_H_
