#include <iostream>
#include "Bank.cpp"
#include "Bank.h"
using namespace std;
int main(){
int n,n1,n2;
cout<<"Enter number of accounts: "<<endl;
cin>>n;
Bank b1[n];
for(int i=0;i<n;i++) {
    b1[i].setinputs();
    cout<<"Enter number of times you want to deposit: "<<endl;
    cin>>n1;
    b1[i].deposit(n1);
    cout<<"Enter number of times you want to withdraw: "<<endl;
    cin>>n2;
    b1[i].withdraw(n2);
    b1[i].display();
}
return 0;
}
