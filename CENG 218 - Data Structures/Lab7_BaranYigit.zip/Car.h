#ifndef CAR_H_
#define CAR_H_
class Car{
private:
    int length,fuel,total;
    int *distance;
public:
    Car();
    Car(int num);
    Car(const Car &obj);
    void getFuel();
    void getConsumption();
    void display();
    void displayfuel();
    int calculatetotalconsumption();
    Car& operator=(const Car &obj);
    int& operator[](const int &k);
    ~Car();
};
#endif // CAR_H_
