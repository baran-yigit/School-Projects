#include<iostream>
using namespace std;
#include "Pedometer.h"
#include "Pedometer.cpp"
int main(){
int n,n1,n2;
cout<<"Choose how many step you want to make: "<<endl;
cin>>n;
Pedometer b1[n];
for(int i=0;i<n;i++) {

    b1[i].setLength(n);
    b1[i].display();
    b1[i].setCalori(n1);
    cout<<"Which step you want to change: "<<endl;
    cin>>n2;
    b1[i].setCalori(n2);
    b1[i].display();
    b1[i].calculatetotal();
}
return 0;
}
