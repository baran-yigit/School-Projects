#include <iostream>
using namespace std;
#include "Bank.h"
Bank::Bank() {
balance=0;
length=1;
size=new int[length];
}
Bank::Bank(int num) {
balance=0;
length=num;
size=new int[length];
}
void Bank::setinputs(){
cout<<"Enter account number: "<<endl;
cin>>account_no;
cout<<"Enter account type: "<<endl;
cin>>account_type;
cout<<"Enter name: "<<endl;
cin>>name;
}
void Bank::deposit(const int &num){
size=new int[num];
for(int i=0;i<num;i++) {
    cout<<"Enter deposit amount: "<<endl;
    cin>>size[i];
    balance+=size[i]; }
}
void Bank::withdraw(const int &num) {
for(int i=0;i<num;i++) {
    int k=0;
    cout<<"Enter withdraw account: "<<endl;
    cin>>k;
    balance-=k;
    if(balance<0) {
       cout<<"Cannot withdraw "<<k<<" because your current balance is not enough."<<endl;
        balance-=k;
        break;
    }
}
}
void Bank::display() {
cout<<"-------------------"<<endl;
cout<<"Account no: "<<account_no<<endl;
cout<<"Name: "<<name<<endl;
cout<<"Account type: "<<account_type<<endl;
cout<<"Balance: "<<balance<<endl;
cout<<"-------------------"<<endl;
}
Bank::~Bank(){
delete[] size;
cout<<"Free memory."<<endl;
}
