#include <iostream>
#include "Car.cpp"
#include "Car.h"
using namespace std;
int main(){
int n,n1,n2;
cout<<"Choose how many times to travel in one time: "<<endl;
cin>>n;
Car b1[n];
while(1){
    cout<<"Choose operation: 1-Get Fuel 2-Go Distance 3-Show Fuel Status 4-Show History 5-Change History 6-Exit"<<endl;
    cin>>n1;

    switch(n1){
case 1: {
    Car b1[n].getFuel();}
case 2:{
    Car b1[n].getConsumption();}
case 3:{
    Car b1[n].displayfuel();}
case 4:{
    Car b1[n].display();}
case 5:{
    Car b1[n].calculatetotalconsumption();}
case 6:{
    return 0;}

}
}
}
