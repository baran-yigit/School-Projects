#include <iostream>
using namespace std;
class rectangle {
public:
    rectangle() {
    length=5; breadth=2; }
    ~rectangle() {
    cout<<"Destructor is executed for the object"<<endl; }
    double area() {
    return length*breadth; }
    void isLength(double x) {
    length=x; }
    void isBreadth(double y) {
    breadth=y; }
private:
    double length,breadth;
};
int main() {
    double length,breadth;
    rectangle array[3];
    for(int  i=0;i<3;i++) {
        cout<<"Enter length and breadth respectively: ";
        cin>>length>>breadth;
        array[i].isLength(length);
        array[i].isBreadth(breadth); }
        for(int  i=0;i<3;i++) {
        cout<<"Area: "<<array[i].area()<<endl; }
        rectangle print;
        cout<<"Object with default constructor(length=5 and breadth=2):"<<endl;
        cout<<"Area: "<<print.area()<<endl;
        return 0;
}

