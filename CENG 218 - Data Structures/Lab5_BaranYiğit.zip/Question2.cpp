#include <iostream>
#include <iomanip>
using namespace std;
class game {
private:
string type;
string name;
double price;
bool buy;
public:
    game() {
    price=0,buy=0; }
    ~game() {
    cout<<"Destructor is executed for the object"<<endl; }
    void Price(double value) {
    if(value>0) {
    price=value; }}
    void Type(string value) {
    type=value; }
    void Name(string value) {
    name=value; }
    int isPrice() {
    return price; }
    string isName() {
    return name; }
    bool isitaffordable() {
    return buy; }
    string isType() {
    return type; }
    void process() {
if(type=="action") {
if(price*90/100<=100)
buy=1; }
else if(type=="strategy") {
if(price*80/100<=100)
buy=1; }
else if(type=="sport") {
if(price*70/100<=100)
buy=1; }
else if(type=="adventure") {
if(price*75/100<=100)
buy=1; }
else { }
                    }
    float isNewPrice(){
if(type=="action") {
return price*90/100; }
else if(type=="strategy") {
    return price*80/100; }
else if(type=="sport") {
    return price*70/100; }
else if(type=="adventure") {
    return price*75/100; }
else { return price; } }
            };
int main() {
int isprice,i;
string istype,isname;
game array[2];
for(i=0;i<2;i++) {
    cout<<"Enter game type: ";
    cin>>istype;
    array[i].Type(istype);
    cout<<"Enter game name: ";
    cin>>isname;
    array[i].Name(isname);
    cout<<"Enter game price: ";
    cin>>isprice;
    array[i].Price(isprice);
    array[i].process(); }
cout<<setw(15)<<left<<"Game Type"<<setw(15)<<"Name"<<setw(15)<<"Price"<<setw(15)<<"New Price"<<setw(15)<<"Buy"<<endl;;
for(i=0;i<2;i++) {
cout<<setw(15)<<left<<array[i].isType()<<setw(15)<<array[i].isName()<<setw(15)<<array[i].isPrice()<<setw(15)<<array[i].isNewPrice()<<setw(15)<<array[i].isitaffordable()<<endl;; }
return 0; }

