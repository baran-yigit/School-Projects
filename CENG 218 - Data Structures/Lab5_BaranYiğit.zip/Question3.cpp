#include <iostream>
#include <iomanip>
#include <string>
using namespace std;
class park {
private:
    char type;
    double entertime,lefttime,price;
public:
    park() { }
    ~park(){
    cout<<"Destructor is executed for the object"<<endl; }
    void isPrice() {
    double time;
if(entertime>lefttime)
    time=24-entertime+lefttime;
else
    time=lefttime-entertime;
if(type=='C') {
    if(time>3) {
    price=1.5*(time-2); } }
    else if(type=='B') {
    if(time>2) {
    price=2.3*(time-2);
    time-=2; }
    if(time<=2) {
    price+=time; } } }
double Hour() {
double time;
if(entertime>lefttime)
    time=24-entertime+lefttime;
else
time=lefttime-entertime;
return time; }
char vehicle() {
return type; }
double getLeavetime() {
return lefttime; }
double getEntertime() {
return entertime; }
double isCost() {
return price; }
void isEntertime(double value) {
entertime=value; }
void isLeavetime(double value) {
lefttime=value; }
void vehicle(char value) {
type=value; } };
int main() {
    int i;
    double entering,leaving;
    char istype;
    park arr[2];
    for(i=0;i<2;i++) {
        cout<<"Enter vehicle type, time entering parking lot, time leaving parking lot: ";
        cin>>istype;
        cin>>entering;
        cin>>leaving;
        arr[i].isLeavetime(leaving);
        arr[i].isEntertime(entering);
        arr[i].vehicle(istype);
        arr[i].isPrice(); }
        cout<<setw(15)<<left<<"Vehicle Type"<<setw(15)<<"Hour"<<setw(15)<<"Price"<<endl;
    for(i=0;i<2;i++) {
        cout<<setw(15)<<left<<arr[i].vehicle()<<setw(15)<<arr[i].Hour()<<setw(15)<<arr[i].isCost()<<endl; }
        return 0; }
